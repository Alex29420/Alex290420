<!DOCTYPE html>

<html>

<head>  </head>
<style>
       nav {
         width:100%;
         text-aling: center;
          }
       
           label { 


          padding:20px;
          font-size: 2.5em;
          }
   
         body {
            background-image: url(https://i.pinimg.com/236x/35/ec/d8/35ecd807034487d03d2f639285e14552.jpg);
             }
            



</style>
</head>

<body>

  <nav>
        <font size="10"> Hola mi amor, feliz 14 de febrerooo &#x1F498 </font>
        
         </nav>

<section>  
 <font size="5"> Hola caracolita se que el 14 ya paso, queria entregarte una cartita en fisico, pero no te quiero arriesgar y te quiero plasmar lo que siento por ti, por este medio. &#x1F48C  &#128140

antes que nada, feliz 14 de febreroo!, me siento triste por el no estar contigo no por haberlo pasado junto a ti, pero creeme que nunca volvera a pasar, te prometo el que nunca estes sola en esas fechas ni en cualquier otro dia.

<img src="kevin.jpg" height="400px" width "300px"> <a href="https://www.youtube.com/watch?v=hIqBkC7bnLI">TE DEDICO ESTA CANCION &#x1F496</a>
  <br>tu eres ese lugar donde encuentro felicidad,tu eres esa estrella brillante en mi cielo obscuro, tu eres esa estrella que le da luz, color, sentido y vida a mi mundo!, tu eres todo eso que un dia sin saberlo nos encontramos nos juntamos y nos unimos, unimos nuestros cuerpo, nuestras mentes, pero sobre todo, nuestras almas, tu alma ahora es mia y mi alma ahora es tuya (suena medio satanico jej).  
 </br> 

dicen que los ojos son la puerta al alma, y saber que en tus ojos yo veo mi alma en ella, y en mi alma estas tu y solo tu, estas tu, la unica persona que yo quiero, aprecio, adoro y amo, esa persona y unica por quien daria todo, esa persona y te he demostrado que haria todo para que tu estes bien, tu eres esa unica persona que logra eso en mi, tu en mi logras muchas cosas, pero sobre todo logras que te admire, te respete y que me enorgullezca de ti  &#x1F48F <br> <img src="yunuen.jpg" height="250px"  width"150px"> </br>



 <h1> <br> TE AMO MUCHO, te amo como no tienes idea mi amor!!!!  &#x1F496  &#x1F496 </br> </h1>
</font>


                                                                                                                                                                          <img src="adi.jpg"   height="300px"  width "50px"> 


<img src="alex.jpg"  height="300px"  width "240px"> toda hermosa esa niña:), cuando te vea asi te dejare jejee






</body>


</html>












